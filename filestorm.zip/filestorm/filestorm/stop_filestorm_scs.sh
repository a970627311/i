#!/bin/bash
echo "Stoping FileStorm SCS--"
pkill stormcatcher-linux-amd64
pkill redis-server
pkill ipfs
pkill scsserver-linux-amd64
echo "FileStorm SCS Stopped."

