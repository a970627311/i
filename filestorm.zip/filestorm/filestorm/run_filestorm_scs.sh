#!/bin/bash
echo "Starting FileStorm SCS--"

#IPFS_PATH=~/.ipfs 
nohup ./ipfs daemon --enable-gc > ipfs.out 2>&1 &
#nohup ./ipfs daemon > ipfs.out 2>&1 &
echo "IPFS Daemon started."

nohup redis-server --port 6379 > redis.out 2>&1 &
echo "Redis Server started. "

nohup ./stormcatcher-linux-amd64 --listen-host-port 127.0.0.1:18080 --redis-host-port 127.0.0.1:6379 --ipfs-host-port 127.0.0.1:5001 --subChain-contract-address 0xe8e8d7c1f3ae998e7c3055c292649e7c1a7f2065 --subChain-address 127.0.0.1:50068/rpc --vnode-address http://120.78.2.59:8547 > ipfs.out 2>&1 &
echo "Storm Catcher started."

nohup ./scsserver-linux-amd64 --rpcdebug --rpcaddr 0.0.0.0 --rpcport 50068 --rpccorsdomain "*" --verbosity 4 > scs.out 2>&1 &
echo "SCS started."

